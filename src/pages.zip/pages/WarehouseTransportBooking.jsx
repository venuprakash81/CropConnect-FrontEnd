import React from "react";
import TransportBookingPage from "./TransportBookingPage";

export default function WarehouseTransportBooking() {
  return (
    <TransportBookingPage
      role="WAREHOUSE"
      title="Warehouse Transport Booking"
    />
  );
}