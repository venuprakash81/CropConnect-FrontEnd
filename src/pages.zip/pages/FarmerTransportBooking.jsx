import React from "react";
import TransportBookingPage from "./TransportBookingPage";

export default function FarmerTransportBooking() {
  return (
    <TransportBookingPage
      role="FARMER"
      title="Farmer Transport Booking"
    />
  );
}