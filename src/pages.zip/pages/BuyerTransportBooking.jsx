import React from "react";
import TransportBookingPage from "./TransportBookingPage";

export default function BuyerTransportBooking() {
  return (
    <TransportBookingPage
      role="BUYER"
      title="Buyer Transport Booking"
    />
  );
}